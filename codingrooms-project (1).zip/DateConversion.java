import java.util.*;

public interface DateConversion{

    //you can assume users string will be formatted as mm/dd/yyyy
    public Date convertDate(String date);
    
}
